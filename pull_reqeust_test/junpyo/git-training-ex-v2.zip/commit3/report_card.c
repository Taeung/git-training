#include<stdio.h>

int main()
{
	printf("This program print report card.\n");
	return 0;
}
